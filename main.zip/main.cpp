﻿#include "framework.h"
#include <iostream>
#include <string>
#include <windows.h>
#include <tlhelp32.h>

void print(const std::string& text) {
    std::cout << text << std::endl;
}

DWORD FindProcessId(const std::wstring& processName) {
    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnap == INVALID_HANDLE_VALUE)
        return 0;

    PROCESSENTRY32W pe;
    pe.dwSize = sizeof(pe);

    DWORD pid = 0;

    if (Process32FirstW(hSnap, &pe)) {
        do {
            if (_wcsicmp(pe.szExeFile, processName.c_str()) == 0) {
                pid = pe.th32ProcessID;
                break;
            }
        } while (Process32NextW(hSnap, &pe));
    }

    CloseHandle(hSnap);
    return pid;
}

int main() {
    print("Searching game process...");
    std::wstring target = L"gmod.exe";
    DWORD pid = FindProcessId(target);

    if (pid == 0) {
        print("Process not found.");
        return 1;
    }

    HANDLE game = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
    if (game == NULL) {
        print("Failed to open process.");
        return 1;
    }

    print("Allocating memory in remote process...");
    SIZE_T sizeToAllocate = 1024 * 1024;

    LPVOID remoteAddr = VirtualAllocEx(game, nullptr, sizeToAllocate, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (remoteAddr == nullptr) {
        print("Failed to allocate memory in remote process.");
        CloseHandle(game);
        return 1;
    }

    std::string tw = "Craxis is the best software";

    print("Writing payload...");

    SIZE_T bytesWritten = 0;
    BOOL writeResult = WriteProcessMemory(game, remoteAddr, tw.c_str(), tw.size() + 1, &bytesWritten);

    if (!writeResult || bytesWritten != tw.size() + 1) {
        print("Failed to write memory.");
        VirtualFreeEx(game, remoteAddr, 0, MEM_RELEASE);
        CloseHandle(game);
        return 1;
    }

    print("Write successful.");
    std::cout << "Data written at remote address: " << remoteAddr << std::endl;

    SIZE_T bytesRead = 0;
    const SIZE_T bufSize = 256;
    char buffer[bufSize] = { 0 };

    BOOL success = ReadProcessMemory(game, remoteAddr, buffer, bufSize - 1, &bytesRead);
    if (!success) {
        print("Failed to read memory.");
    }
    else {
        buffer[bytesRead] = '\0';
        print(std::string(buffer));
    }

    VirtualFreeEx(game, remoteAddr, 0, MEM_RELEASE);



    CloseHandle(game);
    return 0;
}
