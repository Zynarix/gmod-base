#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <array>
#include <windows.h>
#include <tlhelp32.h>
#include <tchar.h>

#include "patterns.h"
#include "sdk.h"